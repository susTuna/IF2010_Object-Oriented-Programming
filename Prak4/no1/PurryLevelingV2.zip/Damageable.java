interface Damageable {
    abstract void takeDamage(int damage);
}