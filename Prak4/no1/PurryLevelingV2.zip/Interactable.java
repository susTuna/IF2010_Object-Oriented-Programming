interface Interactable {
    abstract void interact();
}