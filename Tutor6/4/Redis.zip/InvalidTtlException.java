public class InvalidTtlException extends RuntimeException {

    public InvalidTtlException(String msg) {
        super(msg);
    }
}